package cetvrtavezba;

public class Brojach {

	public static void main(String[] args) {
	}
		public int brojach;
		
		public void zgolemi () {
			this.brojach++;
		}
		
		public void reset () {
			this.brojach = 0;
	
	}

}
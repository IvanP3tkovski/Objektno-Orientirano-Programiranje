package vraboten;

public class Vraboten {
	
	public String ime;
	public String prezime;
	public int plata;
	
	public Vraboten() {
		this.ime = "Aleksandar";
		this.prezime = "Spirovski";
		this.plata = 15000;
	}
}
package domasno1;

public class MyFirstClass {

	public static void main(String[] args) {
		System.out.println("Hello World OOP FIKT");

	}

}

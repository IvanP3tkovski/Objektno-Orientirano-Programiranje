package vrabotenn;

public class Main {
	public static void main(String[] args) {
		Vraboten vraboten1 = new Vraboten();
		
		System.out.println("Imeto na vraboteniot e "+ vraboten1.ime + ".");
		System.out.println("Prezimeto na vraboteniot e " + vraboten1.prezime + ".");
		System.out.println("Negovata plata iznesuva " + vraboten1.plata + "denari.");
		
		
	}
}
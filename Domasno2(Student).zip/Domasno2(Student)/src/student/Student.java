package student;

public class Student {

	public String firstName;
	public String lastName;
	public int index;
	
	public Student ( ) {
		
	}
	
	public Student (String firstName, String lastName, int index) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.index = index;
	}
}
package main;

public class Main {
	public static void main(String[] args) {
		Predmet obj1 = new Predmet ();				
		Predmet obj2 = new Predmet ("Ekonomija i Biznis");
		Predmet obj3 = new Predmet ("Sistemski Softver", "Kostandina Veljanovska", 6);
		
		obj1.ime = "Digitalna logika i sistemi";
		obj1.profesor = "Nikola Rendevski";
		obj1.krediti = 6;
		obj1.semestar = "I-vi";
		
		System.out.println(obj1.ime + " " + obj1.profesor + " " + obj1.krediti + " " + obj1.semestar);
		System.out.println(obj2.ime);
		System.out.println(obj3.ime + " " + obj3.profesor + " " + obj3.krediti);
	}
}
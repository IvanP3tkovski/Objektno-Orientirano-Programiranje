package avtomobil;

public class Avtomobil {
	public String marka;
	public String model;
	public int pominatikilometri;
	
	public Avtomobil () {
		
	}
	
	public Avtomobil (String marka, String model, int kilometraza) {
		this.marka = marka;
		this.model = model;
		this.pominatikilometri = kilometraza;
	}
}
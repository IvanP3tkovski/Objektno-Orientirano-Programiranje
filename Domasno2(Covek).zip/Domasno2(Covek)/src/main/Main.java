package main;

public class Main {
	public static void main (String[] args) {
		Covek obj1 = new Covek();
		
		obj1.ime = "Gorjan";
		obj1.prezime = "Petrovski";
		obj1.mBroj = "0909000421008";
		
		System.out.println("Imeto na covekot e: " + obj1.ime + ".");
		System.out.println("Prezimeto na covekot e: " + obj1.prezime + ".");
		System.out.println("Cvekot ima maticen broj: " + obj1.mBroj + ".");
	}
}
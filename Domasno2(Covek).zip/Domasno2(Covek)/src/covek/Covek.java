package covek;

public class Covek {
	public String ime;
	public String prezime;
	public String mBroj;
	
	//Default Constructor
	public Covek () {
		
	}
}